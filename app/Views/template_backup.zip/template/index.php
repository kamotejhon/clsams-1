<?= view('template\header') ?>
<?= view('template\topbar') ?>
<?= view('template\sidebar') ?>
  <?= view(esc($view)) ?>
<?= view('template\footer') ?>
<?= view('template\notification') ?>

